<?php

$lines = array();
while(!feof(STDIN)){
	$lines[] = trim(str_replace(array("\r", "\n") , "", fgets(STDIN)));
	
}

$Ksoft = intval(array_shift($lines));
$Usoft = intval(array_shift($lines));
$Kcall = intval(array_shift($lines));
$goodware = array();
$malware = array();
$unknown = array();
for($x = 0; $x < $Kcall; ++$x){
	$goodware[$x] = 0;
	$malware[$x] = 0;
}
for($i = 0; $i < $Ksoft; ++$i){
	$line = explode(" ",array_shift($lines));
	$C = array_shift($line) == "S" ? "goodware":"malware";
	$val = array();
	for($x = 0; $x < $Kcall; ++$x){
		if($C == "goodware"){
			$goodware[$x] += intval(trim($line[$x]));
		}else{
			$malware[$x] += intval(trim($line[$x]));
		}
	}

}

for($i = 0; $i < $Usoft; ++$i){
	$line = explode(" ",array_shift($lines));
	$val = array();
	for($x = 0; $x < $Kcall; ++$x){
		$val[$x] = intval(trim($line[$x]));
	}
	$unknown[] = $val;
}

$count = 0;
	$votes = array();
	$vTot = array();
	for($x = 0; $x < $Kcall; ++$x){
		$votes[$x] = 0;
		$vTot[$x] = 0;
	}
	foreach($goodware as $i => $v){
		$votes[$i] += $v;
		$vTot[$i] += $v;
	}
	foreach($malware as $i => $v){
		$votes[$i] -= $v;
		$vTot[$i] += $v;
	}

foreach($unknown as $prog){
	$sel = 0;
	foreach($votes as $i => $v){
		$sel += ($v / $vTot[$i]) * $prog[$i];
	}
	if($sel < 0){
		$count += array_sum($prog);
	}
}

echo $count,PHP_EOL;